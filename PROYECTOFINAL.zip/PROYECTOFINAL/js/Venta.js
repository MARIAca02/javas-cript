function mostrar(){
    let item1=document.getElementById('prod1');
    let item2=document.getElementById('prod2');
    let item3=document.getElementById('prod3');
    let adic=0;
    //1er item factura
    if(item1.selectedIndex==0){    // no se pedir producto combo
        document.getElementById('desc01').value="";
        document.getElementById('vau01').value=0;
        document.getElementById('cant01').value=0;
        document.getElementById('vat01').value=0;
    }
    if(item1.selectedIndex==1){
        document.getElementById('desc01').value="Labial rojo,fussia y vino tinto F.";
        document.getElementById('vau01').value=item1.options[item1.selectedIndex].value;
        document.getElementById('vat01').value=(parseFloat(document.getElementById('cant01').value)*parseFloat(document.getElementById('vau01').value)||0).toFixed(2);
    }
    if(item1.selectedIndex==2){
        document.getElementById('desc01').value="Pestañas largas,medianas, cortas y pegante F.";
        document.getElementById('vau01').value=item1.options[item1.selectedIndex].value;
        document.getElementById('vat01').value=(parseFloat(document.getElementById('cant01').value)*parseFloat(document.getElementById('vau01').value)||0).toFixed(2);
    }
    if(item1.selectedIndex==3){
        document.getElementById('desc01').value="Rubor en crema, polvos,color rosa y bronce F.";
        document.getElementById('vau01').value=item1.options[item1.selectedIndex].value;
        document.getElementById('vat01').value=(parseFloat(document.getElementById('cant01').value)*parseFloat(document.getElementById('vau01').value)||0).toFixed(2);
    }
    // 2do. item factura
    if(item2.selectedIndex==0){    // no se pedir producto combo
        document.getElementById('desc02').value="";
        document.getElementById('vau02').value=0;
        document.getElementById('cant02').value=0;
        document.getElementById('vat02').value=0;
    }
    if(item2.selectedIndex==1){
        document.getElementById('desc02').value=" Labial rojo,fussia y vino tintoF.";
        document.getElementById('vau02').value=item1.options[item1.selectedIndex].value;
        document.getElementById('vat02').value=(parseFloat(document.getElementById('cant02').value)*parseFloat(document.getElementById('vau02').value)||0).toFixed(2);
    }
    if(item2.selectedIndex==2){
        document.getElementById('desc02').value="Pestañas largas,medianas, cortas y pegante F.";
        document.getElementById('vau02').value=item1.options[item1.selectedIndex].value;
        document.getElementById('vat02').value=(parseFloat(document.getElementById('cant02').value)*parseFloat(document.getElementById('vau02').value)||0).toFixed(2);
    }
    if(item2.selectedIndex==3){
        document.getElementById('desc02').value="Rubor en crema, polvos,color rosa y bronce F.";
        document.getElementById('vau02').value=item1.options[item1.selectedIndex].value;
        document.getElementById('vat02').value=(parseFloat(document.getElementById('cant02').value)*parseFloat(document.getElementById('vau02').value)||0).toFixed(2);
    }
    // 3er item de factura
    if(item3.selectedIndex==0){    // no se pedir producto combo
        document.getElementById('desc03').value="";
        document.getElementById('vau03').value=0;
        document.getElementById('cant03').value=0;
        document.getElementById('vat03').value=0;
    }
    if(item3.selectedIndex==1){
        document.getElementById('desc03').value="Labial rojo,fussia y vino tinto F.";
        document.getElementById('vau03').value=item1.options[item1.selectedIndex].value;
        document.getElementById('vat03').value=(parseFloat(document.getElementById('cant03').value)*parseFloat(document.getElementById('vau03').value)||0).toFixed(2);
    }
    if(item3.selectedIndex==2){
        document.getElementById('desc03').value="Pestañas largas,medianas, cortas y pegante F.";
        document.getElementById('vau03').value=item1.options[item1.selectedIndex].value;
        document.getElementById('vat03').value=(parseFloat(document.getElementById('cant03').value)*parseFloat(document.getElementById('vau03').value)||0).toFixed(2);
    }
    if(item3.selectedIndex==3){
        document.getElementById('desc03').value=" Rubor en crema, polvos,color rosa y bronceF.";
        document.getElementById('vau03').value=item1.options[item1.selectedIndex].value;
        document.getElementById('vat03').value=(parseFloat(document.getElementById('cant03').value)*parseFloat(document.getElementById('vau03').value)||0).toFixed(2);
    }
    // Calcular Adicionales ***
    if(document.getElementById('radio4').checked){
        document.getElementById('adic0').value=18000;
    }else if(document.getElementById('radio5').checked){
        document.getElementById('adic0').value=12500;
    }else if(document.getElementById('radio6').checked){
        document.getElementById('adic0').value=15300;
    }
    //calcular subtotal ***
    document.getElementById('subt').value=(parseFloat(document.getElementById('vat01').value)+parseFloat(document.getElementById('vat02').value)+parseFloat(document.getElementById('vat03').value)+parseFloat(document.getElementById('adic0').value)||0).toFixed(2);
    //calcular iva
    document.getElementById('iva').value=(parseFloat(document.getElementById('subt').value)*0.19||0).toFixed(2);
    //calcular descuento
    if(document.getElementById('radio1').checked){  //efectivo
        document.getElementById('desc').value=(parseFloat(document.getElementById('subt').value)*0.10||0).toFixed(2);
    }else if(document.getElementById('radio2').checked){  //nequi
        document.getElementById('desc').value=(parseFloat(document.getElementById('subt').value)*0.00||0).toFixed(2);
    }else if(document.getElementById('radio3').checked){ // tarjeta credito
        document.getElementById('desc').value=(parseFloat(document.getElementById('subt').value)*0.00||0).toFixed(2);
    }
    //calcular neto  *
    document.getElementById('neto').value=(parseFloat(document.getElementById('subt').value)+parseFloat(document.getElementById('iva').value)-parseFloat(document.getElementById('desc').value)||0).toFixed(0);
    }
    //
    function enviar(){
    swal("ESTIAMDO CLIENTE","FAVOR ESPERAR SU PEDIDO PROXIMAMENTE..", "success");
    }