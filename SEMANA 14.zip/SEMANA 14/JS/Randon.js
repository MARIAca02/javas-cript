function apostar(){
    let b=101; // ingrese el ciclo while
    let intentos=0;// contador
    var a=Math.random(Math.random()*100);//genera numero al azar entre 0 a 100
    // ciclo while
    while (a!=b){
    intentos++;
    b=parseInt(prompt("INGRESE VALOR APOSTADO DE 0 A 100"));
        //
    if (b>a){
        alert("EL VALOR ES MAS BAJO");
    }else{
    alert ("EL VALOR ES MAS ALTO");
    }
    }
    document.getElementById("apostado").value=b;
    document.getElementById("resultado").value=a;
    swal ("FELICITACIONES IUSUARIO","HAS ACERTADO NUMERO","success")
    document.getElementById("salida").value= " has acertado a los numeros..."+intentos+"..intentos";
    }
    function cancel(){
    document.getElementById("apostado").value=" ";
    document.getElementById("resultado").value=" ";
    document.getElementById("salida").value=" ";
}

