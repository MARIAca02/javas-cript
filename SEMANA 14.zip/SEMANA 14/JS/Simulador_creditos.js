function calcular() {
    var n1 = document.getElementById("ValorC").value;// de forma 
    var n2 = document.getElementById("NumC").value;
    var n3 = document.getElementById("Interes").value;
    // proceso de calcular
    var ValorA = parseFloat(n1) * parseFloat(n3);
    var ValorB = parseFloat(n1) * (1 + parseFloat(n2) * parseFloat(n3));
    
    document.getElementById("ValorA").value = ValorA;// del js al formulario
    document.getElementById("ValorB").value = ValorB.toFixed(0);

}
function limpiar(){
    document.getElementById("ValorC").value= " ";// borrar input de entra
    document.getElementById("NumC").value=" ";
    document.getElementById("Interes").value= " ";
}

