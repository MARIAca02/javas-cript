var h = 0;  // horas
var m = 0;  // minutos
var s = 0;  // segundos
var mil = 0;  // milisegundos
var apt;

function cronometro() {
    tick();
}

function tick() {
    // Incrementos
    mil++;
    if (mil >= 99) {
        mil = 0;
        s++;
    }
    if (s >= 60) {
        s = 0;
        m++;
    }
    if (m >= 60) {
        m = 0;
        h++;
    }

    // Actualizar los valores en los inputs
    document.getElementById('hora').value = h;
    document.getElementById('minutos').value = m;
    document.getElementById('segundos').value = s;
    document.getElementById('milesimas').value = mil;

    // Llamar a tick nuevamente después de 1 milisegundo
    apt = setTimeout(tick, 1);
}

function parar() {
    clearTimeout(apt);
}

function reiniciar() {
    clearTimeout(apt);
    h = 0;
    m = 0;
    s = 0;
    mil = 0;
    document.getElementById('hora').value = h;
    document.getElementById('minutos').value = m;
    document.getElementById('segundos').value = s;
    document.getElementById('milesimas').value = mil;
}

// Asegúrate de que los campos de entrada están configurados en la página
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('hora').value = h;
    document.getElementById('minutos').value = m;
    document.getElementById('segundos').value = s;
    document.getElementById('milesimas').value = mil;
});